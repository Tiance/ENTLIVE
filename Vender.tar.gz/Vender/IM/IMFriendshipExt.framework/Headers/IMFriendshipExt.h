//
//  IMFriendshipExt.h
//  IMFriendshipExt
//
//  Created by tomzhu on 2017/1/23.
//
//

#ifndef IMFriendshipExt_h
#define IMFriendshipExt_h

#import <ImSDK/ImSDK.h>
#import "TIMComm+FriendshipExt.h"
#import "TIMFriendshipManager+Ext.h"

#endif /* IMFriendshipExt_h */
